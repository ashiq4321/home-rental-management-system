var db = require('./db');

module.exports = {
	getCustomerProfile: function (username, callback) {
		var sql = "select * from customerinfo where username=?";
		db.getResults(sql, username, function (results) {
			if (results.length > 0) {
				callback(results[0]);
			} else {
				callback(null);
			}
		});
	},
	getOwnersProfile: function (username, callback) {
		var sql = "select * from houseownerinfo where username=?";
		db.getResults(sql, username, function (results) {
			if (results.length > 0) {
				callback(results[0]);
			} else {
				callback(null);
			}
		});
	},
	getAllAvailableHouse: function (callback) {
		var sql = "select * from houseinfo where status=?";
		db.getResults(sql, ['available'], function (results) {
			if (results.length > 0) {
				callback(results);
			} else {
				callback([]);
			}
		});
	},
	getAllRentedHouse: function (callback) {
		var sql = "select * from houseinfo where status=?";
		db.getResults(sql, ['rented'], function (results) {
			if (results.length > 0) {
				callback(results);
			} else {
				callback([]);
			}
		});
	},
	validate: function (user, callback) {
		var sql = "SELECT * FROM  customerinfo where username=? and password=?";
		db.getResults(sql, [user.username, user.password], function (results) {
			if (results.length > 0) {
				callback(true);
			} else {
				callback(false);
			}
		});
	},
	getByUname: function (username, callback) {
		var sql = "select * from customerinfo where username=?";
		db.getResults(sql, [username], function (results) {
			if (results.length > 0) {
				callback(results[0]);
			} else {
				callback(null);
			}
		});
	},
	updateProfile: function (user, callback) {
		var sql = "update customerinfo set fname=?,lname=?, username=?, password=?, email=?,phone=?,area=?,fathersName=?,nid=? where username=?";
		db.execute(sql, [user.fname, user.lname, user.username, user.password, user.email, user.phone, user.area, user.fathersName, user.nid, user.username], function (status) {
			if (status) {
				callback(true);
			} else {
				callback(false);
			}
		});
	},
	customerStatus: function (user, callback) {
		var sql = "update customerinfo set status=? where username=?";
		db.execute(sql, [user.status, user.username], function (status) {
			if (status) {
				callback(true);
			} else {
				callback(false);
			}
		});
	},
	recover: function (user, callback) {
		var sql = "select * from customerinfo where username=? and fathersName=?";
		db.getResults(sql, [user.username, user.fathersName], function (results) {
			if (results.length > 0) {
				callback(results);
			} else {
				callback(null);
			}
		});
	},
	passrecovery: function (user, callback) {

		console.log(user)
		var sql = "update customerinfo set password=?  where username=? ";
		db.getResults(sql, [user.password, user.username], function (status) {
			if (status) {
				callback(true);
			} else {
				callback(false);
			}
		});
	}
}