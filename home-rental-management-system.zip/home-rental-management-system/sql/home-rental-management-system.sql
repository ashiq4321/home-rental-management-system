-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2020 at 02:25 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `home-rental-management-system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admininfo`
--

CREATE TABLE `admininfo` (
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admininfo`
--

INSERT INTO `admininfo` (`name`, `username`, `password`, `email`, `phone`) VALUES
('Musaddiq Al Karim', 'admin', 'admin', 'email', '01836252698');

-- --------------------------------------------------------

--
-- Table structure for table `customerinfo`
--

CREATE TABLE `customerinfo` (
  `fname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fathersName` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nid` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportNo` int(10) DEFAULT NULL,
  `status` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customerinfo`
--

INSERT INTO `customerinfo` (`fname`, `lname`, `username`, `password`, `email`, `phone`, `type`, `fathersName`, `nid`, `reportNo`, `status`) VALUES
('Ashiqul Hoque', 'chowdhury', 'cust', 'cust', 'cust', 'cust', 'available', 'cust', '32323', 2, 'block'),
('Ashiqul Hoque', 'chowdhury', 'cust2', 'cust', 'ashiqulhoque45@gmail.com', '01670464084', 'available', 'something', '01670464084', 0, 'unblock'),
('MD', 'SHABUJ', 'shabuj', '987654321', 'c@gmail.com', '01912345678', 'available', 'Rahim', '14785236910111213', 0, 'unblock'),
('ASHIQ', 'CHY', 'usee', 'asasasas', 'ashiqulhoque45@gmail.com', '01670464084', 'pending', 'something', '01670464084121212', 0, 'unblock'),
('Ashiqul Hoque', 'chowdhury', 'what', 'what', 'ehat', '0356', 'available', 'adhgja', 'sdfds', 0, 'unblock');

-- --------------------------------------------------------

--
-- Table structure for table `houseinfo`
--

CREATE TABLE `houseinfo` (
  `houseid` int(10) NOT NULL,
  `housename` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `division` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int(10) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `prize` int(10) NOT NULL,
  `review` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ownersname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customername` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `houseinfo`
--

INSERT INTO `houseinfo` (`houseid`, `housename`, `division`, `area`, `address`, `size`, `description`, `prize`, `review`, `status`, `ownersname`, `customername`) VALUES
(19, 'eshaq', 'Chittagong', 'Chandgoan', 'jskdhjdsf', 3200, 'fdhdhdhd', 40000, 'valo na', 'banned', 'manna', ''),
(50, 'eshaq', 'Chittagong', 'Chandgoan', 'jskdhjdsf', 3200, 'fdhdhdhd', 40000, 'valo na', 'banned', 'manna', ''),
(200, 'bali', 'Chittagong', 'Chandgoan', 'jskdhjdsf', 3200, 'fdhdhdhd', 40000, 'valo na', 'available', 'manna', ''),
(3000, 'mati', 'Chittagong', 'Chandgoan', 'jskdhjdsf', 3200, 'fdhdhdhd', 40000, 'valo na', 'available', 'manna', '');

-- --------------------------------------------------------

--
-- Table structure for table `houseownerinfo`
--

CREATE TABLE `houseownerinfo` (
  `fname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fathersName` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nid` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportNo` int(10) NOT NULL,
  `status` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `houseownerinfo`
--

INSERT INTO `houseownerinfo` (`fname`, `lname`, `username`, `password`, `email`, `phone`, `type`, `fathersName`, `nid`, `reportNo`, `status`) VALUES
('Ashiqul Hoque', 'chowdhury', 'cust2', 'cust', 'ashiqulhoque45@gmail.com', '01670464084', 'available', 'something', '01670464084', 0, 'block'),
('dfdf', 'df', 'fdf', 'dff', 'df', 'df', 'available', 'sa', 'sa', 0, 'block'),
('MD', 'KAMAL', 'kamal', '12345678', 'mdkamal@gmail.com', '01980314972', 'available', 'Bashar', '10203040506070809', 0, 'unblock'),
('MUSADDIQ AL', 'KARIM', 'musa123', '12341234', 'm@gmail.com', '01705719021', 'pending', 'MRK', '24554578012471547', 0, 'unblock'),
('MOSTAFA', 'RASEL', 'rasel', '123123123', 'mostafarasel9@gmail.com', '01980314972', 'available', 'Khairul Bashar', '12345678998765432', 0, 'unblock'),
('Mostafa', 'karim', 'sa', '123', 'mostafarasel9@gmail.com', '01980314972', 'available', 'Khirul Bashar', 'sa', 0, ''),
('MD', 'SAGOR', 'sagor', '123123123', 'ashiqulhoque45@gmail.com', '01670464084', 'pending', 'Khairul Bashar', '01670464084121212', 0, 'block');

-- --------------------------------------------------------

--
-- Table structure for table `incustomerinfo`
--

CREATE TABLE `incustomerinfo` (
  `customername` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `houseownername` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `houseid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `incustomerinfo`
--

INSERT INTO `incustomerinfo` (`customername`, `houseownername`, `houseid`) VALUES
('joy', 'bangla', 14);

-- --------------------------------------------------------

--
-- Table structure for table `managerinfo`
--

CREATE TABLE `managerinfo` (
  `fname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `division` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fathersName` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nid` int(20) NOT NULL,
  `status` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `managerinfo`
--

INSERT INTO `managerinfo` (`fname`, `lname`, `username`, `password`, `email`, `phone`, `division`, `area`, `fathersName`, `nid`, `status`) VALUES
('Ashiqul Hoque', 'chowdhury', 'as', 'as', 'ashiqulhoque45@gmail.com', '1670464084', 'Chittagong', 'Chandgaon', 'something', 16704, 'block'),
('asd', 'asd', 'asd', '123', 'asd', 'asd', 'Dhaka', 'Bashundhara', 'asd', 21455, 'unblock'),
('Ashiqul Hoque', 'CHY', 'ashiq4321', 'password', 'ashiqulhoque45@gmail.com', '1823828500', 'Dhaka', NULL, 'shafiqul hoque chowdhury', 11223344, ''),
('rasel', 'mostafa', 'rasel', '12341234', 'r@gmail.com', '01612345678', 'Chittagong', 'Agrabad', 'Khairul Bashar', 2147483647, 'unblock');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admininfo`
--
ALTER TABLE `admininfo`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `customerinfo`
--
ALTER TABLE `customerinfo`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `nid` (`nid`);

--
-- Indexes for table `houseinfo`
--
ALTER TABLE `houseinfo`
  ADD PRIMARY KEY (`houseid`);

--
-- Indexes for table `houseownerinfo`
--
ALTER TABLE `houseownerinfo`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `incustomerinfo`
--
ALTER TABLE `incustomerinfo`
  ADD PRIMARY KEY (`houseownername`);

--
-- Indexes for table `managerinfo`
--
ALTER TABLE `managerinfo`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `nid` (`nid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
