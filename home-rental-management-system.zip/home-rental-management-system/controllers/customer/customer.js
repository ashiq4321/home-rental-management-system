var express = require('express');
var router = express.Router();
var customerModel = require.main.require('./models/customer-model');

router.get('*', function (req, res, next) {
	if (req.cookies['uname'] == null) {
		res.redirect('/login');
	} else {
		next();
	}
});
router.get('/', function (req, res) {
	console.log(req.cookies['uname'])
	customerModel.getByUname(req.cookies['uname'], function (result) {
		res.render('customer/index', {
			user: result
		});
	});
});

router.get('/profile', function (req, res) {
	customerModel.getByUname(req.cookies['uname'], function (result) {
		res.render('customer/profile', {
			user: result
		});
	});

});
router.post('/profile', function (req, res) {
	if (req.body.password == req.body.cpassword) {
		var user = {
			fname: req.body.fname,
			lname: req.body.lname,
			username: req.body.uname,
			fathersName: req.body.fathersName,
			email: req.body.email,
			phone: req.body.phone,
			nid: req.body.nid,
			password: req.body.password,
			area: req.body.area
		};

		customerModel.updateProfile(user, function (status) {
			if (status) {
				res.redirect('/customer');
			} else {
				res.redirect('/customer/profile');
			}
		});
	} else {
		res.send('password mismatch');
	}
});
router.get('/pendingCustomers', function (req, res) {
	customerModel.getAllPendingCustomer(function (results) {
		if (results.length > 0) {
			res.render('customer/pendingCustomers', {
				userlist: results
			});
		} else {
			res.render('customer/pendingCustomers', {
				userlist: results
			});
		}
	});

});
router.get('/pendingHouseowners', function (req, res) {
	customerModel.getAllPendingHouseowner(function (results) {
		if (results.length > 0) {
			res.render('customer/pendingHouseowners', {
				userlist: results
			});
		} else {
			res.render('customer/pendingHouseowners', {
				userlist: results
			});
		}
	});

});
router.get('/pendingCustomers/accept/:username', function (req, res) {
	customerModel.acceptCustomer(req.params.username, function (status) {
		if (status) {
			res.redirect('/customer/pendingCustomers');
		} else {
			res.send('error');
		}
	});
});
router.get('/pendingCustomers/reject/:username', function (req, res) {
	customerModel.deleteCustomer(req.params.username, function (status) {
		if (status) {
			res.redirect('/customer/pendingCustomers');
		} else {
			res.send('error');
		}
	});
});
router.get('/pendingHouseowners/accept/:username', function (req, res) {
	customerModel.acceptHouseOwner(req.params.username, function (status) {
		if (status) {
			res.redirect('/customer/pendingHouseowners');
		} else {
			res.send('error');
		}
	});
});
router.get('/pendingHouseowners/reject/:username', function (req, res) {
	customerModel.deleteHouseOwner(req.params.username, function (status) {
		if (status) {
			res.redirect('/customer/pendingHouseowners');
		} else {
			res.send('error');
		}
	});
});
router.get('/view_Customers', function (req, res) {
	customerModel.getAllAvailableCustomer(function (results) {
		if (results.length > 0) {
			res.render('customer/view_Customers', {
				userlist: results
			});
		} else {
			res.render('customer/view_Customers', {
				userlist: results
			});
		}
	});

});
router.get('/view_Owners', function (req, res) {
	customerModel.getAllAvailableHouseowner(function (results) {
		if (results.length > 0) {
			res.render('customer/view_Owners', {
				userlist: results
			});
		} else {
			res.render('customer/view_Owners', {
				userlist: results
			});
		}
	});

});
router.get('/view_Customers/:username', function (req, res) {
	customerModel.getCutomerProfile(req.params.username, function (result) {
		res.render('customer/getProfile', {
			user: result,
			table: 'customerinfo'
		});
	});

});
router.get('/view_Owners/:username', function (req, res) {
	customerModel.getOwnersProfile(req.params.username, function (result) {
		res.render('customer/getProfile', {
			user: result,
			table: 'houseownerinfo'
		});
	});

});
//block unblock
router.get('/houseownerinfo/:username', function (req, res) {
	customerModel.getOwnersProfile(req.params.username, function (result) {
		if (result.status == "block") {
			var user = {
				username: req.params.username,
				status: 'unblock'
			};
		} else {
			var user = {
				username: req.params.username,
				status: 'block'
			};
		}
		customerModel.houseOwnersStatus(user, function (status) {
			if (status) {
				customerModel.getOwnersProfile(req.params.username, function (result) {
					res.render('customer/getProfile', {
						user: result,
						table: 'houseownerinfo'
					});
				});
			} else {
				res.send('error');
			}
		});

	});
});
router.get('/customerinfo/:username', function (req, res) {
	customerModel.getCutomerProfile(req.params.username, function (result) {
		if (result.status == "block") {
			var user = {
				username: req.params.username,
				status: 'unblock'
			};
		} else {
			var user = {
				username: req.params.username,
				status: 'block'
			};
		}
		customerModel.customerStatus(user, function (status) {
			if (status) {
				customerModel.getCutomerProfile(req.params.username, function (result) {
					res.render('customer/getProfile', {
						user: result,
						table: 'customerinfo'
					});
				});
			} else {
				res.send('error');
			}
		});

	});
});
router.get('/view_Rented', function (req, res) {
	customerModel.getAllRentedHouse(function (results) {
		if (results.length > 0) {
			res.render('customer/view_Rented', {
				userlist: results
			});
		} else {
			res.render('customer/view_Rented', {
				userlist: results
			});
		}
	});

});
router.get('/view_Available', function (req, res) {
	customerModel.getAllAvailableHouse(function (results) {
		if (results.length > 0) {
			res.render('customer/view_Available', {
				userlist: results
			});
		} else {
			res.render('customer/view_Available', {
				userlist: results
			});
		}
	});

});
router.get('/view_Rented/:id', function (req, res) {
	customerModel.deleteHouse(req.params.id, function (status) {
		if (status) {
			res.redirect('/customer/view_Rented');
		} else {
			res.send('error');
		}
	});
});
router.get('/view_Available/:id', function (req, res) {
	customerModel.deleteHouse(req.params.id, function (status) {
		if (status) {
			res.redirect('/customer/view_Available');
		} else {
			res.send('error');
		}
	});
});
module.exports = router;